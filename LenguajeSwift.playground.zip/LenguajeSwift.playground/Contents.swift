import UIKit

// Variables Constantes
let ciclo: Int
var edad: Int = 21
edad = 22

var a = 0 , b = 0, c = 0

var name: String = "Jose"; var lastname = "Gonzales"

// Tipos de Anotaciones
var bienvenido = "String" //String
var tipoCambio = 3.70 //Double

// Impresiones
print(bienvenido)
print(name)

// Interpolación de cadenas
print("Mi nombre \(name)")

//Tipos de Datos
var entero: Int = 0
var cadena: String = "Hola"
var flotante: Float = 15.4
var decimal: Double = 3.5
var boleano: Bool = true

var mes: Int = 11
var maxInt = Int.max
var minInt = Int.min

// Enteros sin signo - positivos
var mesPositivo: UInt = 11

// Puntos flotantes
var valueFloat: Float = 3.70
var valueDoble: Double = 45.454545

// Booleanos
var aprobareCurso: Bool = false
if aprobareCurso{
    print("Feliz Navidad")
}else {
    print("Feliz susti - 30 soles")
}

// Operadores básicos
print(4+4)
print(5-2)
print(5*5)
print(20/5)
print(9%4) //Operador módulo = 1

// Operador Condicional Ternario
var mayoriaEdad = 18
if mayoriaEdad == 18{
    print("Puedo votar")
}else{
    print("Aun no puedo votar")
}

var msj = (mayoriaEdad == 18) ? "Puedo votar":"No voto"
print(msj)

// Tuplas

// Colecciones
// Arreglos (Es importante el orden)
var misNotas:[Int] = [20,13,10,20]
misNotas.append(15)
misNotas.first
misNotas.last
misNotas.removeFirst()
misNotas.removeLast()
misNotas.removeAll()
var segundo = misNotas[2]

for item in misNotas{
    print(item)
}

for(index,item) in misNotas.enumerated(){
    print("\(index):\(item)")
}

// Diccionarios (Es importante el orden)
var eventos: [Int:String] = [:]
eventos[2001] = "11 de setiembre"
eventos[1821] = "Independencia del Perú"
eventos[1969] = "Hombre en la luna"

for(key,evento) in eventos{
    print("\(key):\(evento)")
}

eventos.removeValue(forKey: 2001)
eventos.removeAll()
eventos.first

// Conjuntos (No es importante el orden)
var hermanos: Set<String> = ["Jose","Luis","Maria"]
hermanos.first

// While
var maximo = 10
var contador = 0
while contador < maximo {
    print(contador)
    contador += 1
}

// Do While -> Repeat While
var maximoAlt = 10
var contadorAlt = 0
repeat{
    print(contadorAlt)
    contadorAlt += 1
} while contadorAlt < maximoAlt
            
            
