import UIKit

// Class vs Struct
struct Persona {
    var nombre: String
    var apellido: String
}

class PersonaClass{
    var nombre: String
    var apellido: String
    
    init(nombre: String, apellido: String) {
        self.nombre = nombre
        self.apellido = apellido
    }
}

// Los atributos deben ser inicializados en la clase, en la estructura no
// Dentro del bloque de inicialización todos los atributos de la clase deben ser inicializados


class Estudiante: PersonaClass{
    var codigo: String

    init(codigo: String, nombre: String, apellido: String) {
        self.codigo = codigo
        super.init(nombre: nombre, apellido: apellido)
    }
}

// Si colocas FINAL antes de CLASS no permite aceptar más clases hijas, para cerrar una clase
// Las clases son de tipo referencia y las estructuras de tipo valor

// Class - Tipo Referencia
var personaClass = PersonaClass(nombre: "Arturo", apellido: "Anticona")
var personaClass2 = personaClass
personaClass2.nombre = "Erick"

print(personaClass.nombre)
print(personaClass2.nombre)

// Struct - Tipo Valor
var persona = Persona(nombre: "Arturo", apellido: "Anticona")
var persona2 = persona
persona2.nombre = "Erick"
print(persona.nombre)
print(persona2.nombre)

// Las estructuras no permiten herencia

